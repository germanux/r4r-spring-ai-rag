# Ejecución triple-window

Instancia local de evaluación en http://127.0.0.1:18081. PostgreSQL NAS; S3, fallback y Titan deshabilitados solo en estos procesos. Flyway y catálogo al arranque deshabilitados para evitar modificaciones del esquema/corpus. Warmup automático deshabilitado; modelos, topK, reranking, prompts, preguntas y auditoría conservan la configuración del proyecto. Cada tanda contiene las suites existentes ES y EN, sin la regresión opcional adicional.

Comandos de preparación:
```
mvn -q -DskipTests compile
mvn -q -DskipTests test-compile dependency:build-classpath -Dmdep.outputFile=/tmp/r4r-triple-classpath
```
La configuración efectiva de cada proceso Spring se conserva en effective-config.json. Los snapshots SQL contienen cantidades y una huella MD5 ordenada por ID de ID, contenido, metadatos y embedding de todos los vectores originales. Las huellas se verifican antes de cada tanda y tras insertar.

La ejecución usa el runner existente:
```
RAG_TEST_BASE_URL=http://127.0.0.1:18081 RAG_TIMELINE_REGRESSION=false mvn -q -Pllm-it -Dit.test=RagLiveQuestionsIT,RagLiveEnglishQuestionsIT -Dr4r.test.results-dir=<fase> -Dr4r.test.run-id=threshold-<NNN> failsafe:integration-test failsafe:verify
```
El proceso local se arranca con R4rExperimentServer (adaptador temporal que llama a SpringApplication.run y exporta las propiedades efectivas), usando:
```
java -Dexperiment.config-output=<archivo> -cp <classpath> R4rExperimentServer --server.address=127.0.0.1 --server.port=18081 --r4r.rag.retrieval.min-score=<threshold> --r4r.rag.vector.primary=pgvector --r4r.rag.vector.failover-enabled=false --r4r.rag.vector.s3vectors.enabled=false --r4r.rag.vector.titan.enabled=false --spring.flyway.enabled=false --r4r.catalog-on-startup=false --r4r.rag.warmup.on-startup=false
```

Ejecuciones y errores técnicos:

Antes: 1375 vectores; originales=1375; experimentales=0.

- baseline/threshold-050: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

- baseline/threshold-054: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.
Technical failure at line 50

Error técnico transitorio antes de baseline/threshold-057: NoRouteToHostException al conectar a PostgreSQL. Reintento SQL satisfactorio; se continúa desde 0.57 sin repetir ni sobrescribir las tandas completadas. Logs originales conservados en logs/vectors-baseline-057-attempt1.log y logs/network-retry.log.

- baseline/threshold-057: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

- baseline/threshold-061: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

Indexer command: `mvn -q org.codehaus.mojo:exec-maven-plugin:3.5.1:java -Dexec.mainClass=com.riansares.r4r.ingestion.ExperimentalTripleWindowIndexer -Dexec.args=--dry-run`

Indexer command: `mvn -q org.codehaus.mojo:exec-maven-plugin:3.5.1:java -Dexec.mainClass=com.riansares.r4r.ingestion.ExperimentalTripleWindowIndexer -Dexec.args=--apply`

Después de insertar: total=2070; originales=1375; experimentales=695. Huella de originales idéntica.

- triple-window/threshold-050: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

- triple-window/threshold-054: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

- triple-window/threshold-057: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

- triple-window/threshold-061: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

Final: 8/8 tandas; 560/560 JSON individuales. Vectores: total=2070; originales=1375; experimentales=695; originales intactos. Experimentales conservados; sin rollback. Notificaciones: una llamada por tanda y cinco llamadas al finalizar.

Comprobación final: 560 JSON individuales y 8 summary.json; configuración efectiva del servidor idéntica salvo minScore; cero errores de ejecución Failsafe (los fallos de aserción se conservan en los informes); huella de los 1.375 originales idéntica; 695 experimentales conservados; 13 llamadas al notificador verificadas en logs/notifications.log. Validación en validation-final.json.

Conteo automático de errores operativos (sin inspección semántica de respuestas): {"non200HttpResponses": {"500": 1}, "auditTechnicalErrors": {"audit_inconclusive_or_mismatched": 72}, "exportErrors": 0}; detalle en technical-errors.json.

## Ampliación: thresholds 0.44, 0.47, 0.49 y 0.52

Cuatro tandas adicionales ES+EN con los 2.070 vectores existentes (1.375 originales y 695 experimentales). Mismo runner y comando Spring documentados arriba, solo cambia minScore. Sin indexación ni rollback. Se verifica además la huella de todos los vectores antes de cada tanda y al finalizar. Archivos nuevos bajo triple-window/threshold-044, threshold-047, threshold-049 y threshold-052; logs nuevos bajo logs/triple-window-<NNN>-*. No se sobrescriben tandas previas.

- triple-window/threshold-044: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

- triple-window/threshold-047: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

- triple-window/threshold-049: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

- triple-window/threshold-052: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

Ampliación final: 4 tandas; 280/280 JSON individuales y 4/4 summary.json; vectores=2070 (originales=1375, experimentales=695); huella de todos los vectores sin cambios=True. Nueve llamadas adicionales al notificador: una por tanda y cinco al finalizar. Ver validation-extra.json.

Errores operativos de la ampliación (conteo automático): HTTP no-200={}; auditoría={'audit_inconclusive_or_mismatched': 58}; exportación=0; Failsafe execution errors=0. Fallos de aserción conservados sin alterar expectativas.

## Tanda adicional: minScore=0.48

Mismo runner ES+EN, configuración Spring y 2070 vectores. Resultados nuevos en triple-window/threshold-048; logs en logs/triple-window-048-*.

Tanda 0.48 interrumpida por solicitud del usuario para incorporar el auditor actualizado. Intento parcial de 15 JSON preservado en attempts/threshold-048-before-auditor-update-20261114T182326Z. Se recompila y reinicia la tanda completa; no se mezclan versiones del auditor. Comando de comprobación: mvn -q -Dtest=RagAuditCalibrationTest test; log en logs/auditor-updated-calibration.log. Huella del auditor actualizado en logs/auditor-048-source.sha256.

## Tanda adicional: minScore=0.48

Mismo runner ES+EN, configuración Spring y 2070 vectores. Resultados nuevos en triple-window/threshold-048; logs en logs/triple-window-048-*.

- triple-window/threshold-048: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

Validación técnica de threshold-048: {"expected": 70, "individualJsonCount": 70, "summaryTotal": 70, "allExpectedPresent": true, "jsonErrors": [], "runnerExitCode": 1, "valid": true, "finalVectors": 2070, "allVectorsUnchanged": true, "non200HttpResponses": {}, "auditTechnicalErrors": {}, "failsafeErrors": 0, "exportErrors": 0}. Notificador: una llamada al terminar la tanda y cinco llamadas finales.

## Tres tandas: minScore=0.49; topK=4,6,7

Mismo runner ES+EN y auditor actualizado; 2070 vectores. Overrides en el proceso Spring: --r4r.rag.retrieval.min-score=0.49 --r4r.rag.retrieval.top-k=<4|6|7>. Resto de propiedades efectivas contrastadas con threshold-048. Las modificaciones locales del usuario a .env.base permanecen intactas. Compilación: mvn -q -DskipTests test-compile dependency:build-classpath.

- triple-window/threshold-049-topk-4: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

- triple-window/threshold-049-topk-6: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

- triple-window/threshold-049-topk-7: 70/70 JSON individuales; summary.total=70; validación estructural=True; runner exit=1 (los fallos de aserción se conservan sin modificar expectativas). Archivos: JSON individuales, summary.json, effective-config.json, validation.json, failsafe-reports; logs en logs/.

Validación técnica topK 4,6,7: {"batches": [{"batch": "triple-window/threshold-049-topk-4", "expected": 70, "individualJsonCount": 70, "summaryTotal": 70, "allExpectedPresent": true, "jsonErrors": [], "runnerExitCode": 1, "valid": true, "topK": 4, "failsafeErrors": 0}, {"batch": "triple-window/threshold-049-topk-6", "expected": 70, "individualJsonCount": 70, "summaryTotal": 70, "allExpectedPresent": true, "jsonErrors": [], "runnerExitCode": 1, "valid": true, "topK": 6, "failsafeErrors": 0}, {"batch": "triple-window/threshold-049-topk-7", "expected": 70, "individualJsonCount": 70, "summaryTotal": 70, "allExpectedPresent": true, "jsonErrors": [], "runnerExitCode": 1, "valid": true, "topK": 7, "failsafeErrors": 0}], "individualJsonCount": 210, "summaryJsonCount": 3, "finalVectors": 2070, "allVectorsUnchanged": true, "non200HttpResponses": {}, "auditTechnicalErrors": {"audit_inconclusive_or_mismatched": 8}, "exportErrors": 0}. Notificador: una llamada por tanda y cinco llamadas finales.
